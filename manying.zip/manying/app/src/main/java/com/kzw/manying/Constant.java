package com.kzw.manying;

/**
 * author: kang4
 * Date: 2019/9/23
 * Description:
 */
public class Constant {
    public static final String BASEURL = "https://www.okzy.co";

    public static final String SEARCH = BASEURL + "/index.php?m=vod-search";
}
