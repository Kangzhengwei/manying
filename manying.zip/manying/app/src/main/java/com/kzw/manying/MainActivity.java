package com.kzw.manying;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Button;
import android.widget.EditText;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity {

    @InjectView(R.id.edit_url)
    EditText editUrl;
    @InjectView(R.id.search)
    Button search;
    @InjectView(R.id.recyclerView)
    RecyclerView recyclerView;
    SearchListAdapter adapter;
    public List<SearchItem> items = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.inject(this);
        inivew();
    }

    private void inivew() {
        LinearLayoutManager manager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(manager);
        adapter = new SearchListAdapter();
        recyclerView.setAdapter(adapter);
        adapter.setOnItemClickListener(new SearchListAdapter.OnItemClickListener() {
            @Override
            public void itemClick(SearchItem item) {
                Intent intent = new Intent();
                intent.setClass(MainActivity.this,VideoDetailActivity.class);
                intent.putExtra("url", item.getUrl());
                startActivity(intent);
            }
        });
    }

    @OnClick(R.id.search)
    public void onViewClicked() {
        Map<String, Object> params = new HashMap<>();
        params.put("wd", editUrl.getText().toString());
        params.put("submit", "search");
        OkhClientUtil.getInstance().postHtml(Constant.SEARCH, params, new OkhClientUtil.getResult() {
            @Override
            public void result(String result) {
                items.clear();
                Document document = Jsoup.parse(result);
                Elements elements = document.getElementsByClass("xing_vb");
                for (Element postItem : elements) {
                    //像jquery选择器一样，获取文章标题元素
                    Elements list = postItem.getElementsByClass("xing_vb4");
                    for (Element item : list) {
                        Element link = item.select("a").first();
                        String relHref = link.attr("href");
                        SearchItem search = new SearchItem(item.text(), Constant.BASEURL + relHref);
                        items.add(search);
                    }
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        adapter.setList(items);
                    }
                });
            }
        });

    }
}
