package com.kzw.manying;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * author: kang4
 * Date: 2019/9/23
 * Description:
 */
public class SeriesAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<UrlPlayBean.Url> list;

    public SeriesAdapter(List<UrlPlayBean.Url> list) {
        this.list = list;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView series;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            series = itemView.findViewById(R.id.series);
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.series_item, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        UrlPlayBean.Url url = list.get(i);
        ((ViewHolder) viewHolder).series.setText(url.getVideoSeries());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}
