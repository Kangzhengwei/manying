package com.kzw.manying;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.ArrayList;
import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class VideoDetailActivity extends AppCompatActivity {

    @InjectView(R.id.recyclerView)
    RecyclerView recyclerView;
    private List<UrlPlayBean> urlPlaylist = new ArrayList<>();
    public VideoSeriesAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_detail);
        ButterKnife.inject(this);
        initview();
        getdata();
    }

    public void initview() {
        LinearLayoutManager manager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(manager);
        adapter = new VideoSeriesAdapter(this);
        recyclerView.setAdapter(adapter);
    }

    public void getdata() {
        String url = getIntent().getStringExtra("url");
        OkhClientUtil.getInstance().getHtml(url, new OkhClientUtil.getResult() {
            @Override
            public void result(String result) {
                Document document = Jsoup.parse(result);
                Elements elements = document.getElementsByClass("vodplayinfo");
                for (Element element : elements) {
                    Elements ul = element.getElementsByTag("ul");
                    if (ul != null && !TextUtils.isEmpty(ul.toString())) {
                        int i = 0;
                        for (Element ulitem : ul) {
                            Elements suf = element.getElementsByClass("suf");
                            Elements liItem = ulitem.getElementsByTag("li");
                            UrlPlayBean bean = new UrlPlayBean();
                            bean.setUrlType(suf.get(i).text());
                            List<UrlPlayBean.Url> urlist = new ArrayList();
                            for (Element li : liItem) {
                                UrlPlayBean.Url url = new UrlPlayBean.Url();
                                url.setVideoSeries(StringUtil.subString(li.text(), 0));
                                url.setVideoUrl(StringUtil.subString(li.text(), 1));
                                urlist.add(url);
                                System.out.println(suf.get(i).text() + "集数：" + StringUtil.subString(li.text(), 0) + "链接:" + StringUtil.subString(li.text(), 1));
                            }
                            bean.setList(urlist);
                            i++;
                            urlPlaylist.add(bean);
                        }
                    }
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        adapter.setPlayBeanList(urlPlaylist);
                    }
                });
            }
        });

    }
}
